<?php

require_once "IMac.php";

interface iMacInterface{
    public function encender();
    public function mostrarInfo();


}